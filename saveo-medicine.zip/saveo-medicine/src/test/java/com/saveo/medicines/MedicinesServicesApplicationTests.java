package com.saveo.medicines;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicinesServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
