package com.saveo.medicines.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.saveo.medicines.entity.Medicine;
import com.saveo.medicines.service.MedicineService;

@RestController
@RequestMapping("/api")
public class MedicineRestController {

	private MedicineService medicineService;
	
	//use constructor Injection
	@Autowired
	public MedicineRestController(MedicineService themedicineService) {
			medicineService=themedicineService;
	}
	
	@GetMapping("/getMedicineDetails/{theId}")
	public Medicine getMedicine(@PathVariable String theId) {
		Medicine theMedicine = medicineService.findById(theId);
		
		if(theMedicine==null) {
			System.out.println(theMedicine);
			throw new RuntimeException("item id not Found - "+theId);
		}
		return  theMedicine;
	}
	
	
	@GetMapping("/searchMedicine/{itemName}")
	public List<Medicine> getAllMedicine(@PathVariable String itemName) {
		List<Medicine> theMedicine = medicineService.findAll(itemName);
		
		if(theMedicine.size()==0) {
			throw new RuntimeException("item name not Found - "+itemName);
		}
		return  theMedicine;
	}
	
	@PostMapping("/placeorder")
	public long placeOrder(@RequestBody List<Medicine> theMedicine) {
		
		long orderid =medicineService.save(theMedicine);
		
		return orderid;
	}
}
