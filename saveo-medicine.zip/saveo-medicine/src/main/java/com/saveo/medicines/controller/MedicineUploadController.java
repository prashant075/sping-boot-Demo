package com.saveo.medicines.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.saveo.medicines.service.MedicineService;

@Controller
public class MedicineUploadController {

	private MedicineService medicineService;

	// use constructor Injection
	@Autowired
	public MedicineUploadController(MedicineService themedicineService) {
		medicineService = themedicineService;
	}

	@GetMapping("/uploadcsv")
	public String index(Model theModel) {
		return "csvupload/uploadform.html";
	}

	@PostMapping("/uploadcsv")
	public String uploadMultipartFile(@RequestParam("uploadfile") MultipartFile file, Model model) {
		try {
			medicineService.upload(file);
			model.addAttribute("message", "File uploaded");
		} catch (Exception e) {
			model.addAttribute("message", "File Not uploaded ");
		}
		return "csvupload/uploadform.html";
	}
}
