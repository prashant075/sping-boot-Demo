CREATE DATABASE  IF NOT EXISTS `db_saveo`;
USE `db_saveo`;

--
-- Table structure for table `employee`
--
select  *  from medicine where c_batch_no='sds' LIMIT 1;
DROP TABLE IF EXISTS `medicine`;

CREATE TABLE `medicine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(45) DEFAULT NULL,
 `c_batch_no`  varchar(45) DEFAULT NULL,
  `d_expiry_date` varchar(45) DEFAULT NULL,
  `n_balance_qty` int(5) DEFAULT NULL,
   `c_packaging` varchar(45) DEFAULT NULL,
  `c_unique_code` varchar(45) DEFAULT NULL,
  `c_schemes` varchar(45) DEFAULT NULL,
   `n_mrp` double DEFAULT NULL,
  `c_manufacturer` varchar(45) DEFAULT NULL,
  `hsn_code` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

select * from medicine

