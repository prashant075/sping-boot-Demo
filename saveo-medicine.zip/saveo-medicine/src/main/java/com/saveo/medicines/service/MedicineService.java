package com.saveo.medicines.service;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.saveo.medicines.dao.MedicineDao;
import com.saveo.medicines.entity.Medicine;
import com.saveo.medicines.utility.MedicineCsvParse;

@Service
public class MedicineService {
	
	private MedicineDao medicineDao;
	private MedicineCsvParse csvUtil;

	@Autowired
	public MedicineService(MedicineDao theMedicineDao) {
		medicineDao = theMedicineDao;
	}

	@Transactional
	public void upload(MultipartFile file) {
		try {
			List<Medicine> lstMedicines = csvUtil.parser(file.getInputStream());
			medicineDao.saveAll(lstMedicines);

		} catch (IOException e) {
			throw new RuntimeException("message = " + e.getMessage());
		}
	}

	@Transactional
	public List<Medicine> findAll(String itemname) {

		return medicineDao.findAll(itemname);
	}

	@Transactional
	public Medicine findById(String theId) {

		return medicineDao.findById(theId);
	}

	@Transactional
	public long save(List<Medicine> theMedicine) {
		Random random = new Random();
		long orderid = Math.round(random.nextFloat() * Math.pow(10, 10));
		return orderid;

	}
}
