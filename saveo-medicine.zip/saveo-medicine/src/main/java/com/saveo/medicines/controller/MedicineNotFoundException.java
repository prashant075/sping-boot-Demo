package com.saveo.medicines.controller;

public class MedicineNotFoundException extends RuntimeException{

	public MedicineNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public MedicineNotFoundException(String arg0) {
		super(arg0);
		
	}

	public MedicineNotFoundException(Throwable arg0) {
		super(arg0);
		
	}
	
	

}
