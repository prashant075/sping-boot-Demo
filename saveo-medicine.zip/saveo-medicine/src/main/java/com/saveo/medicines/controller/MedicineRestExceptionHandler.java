package com.saveo.medicines.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class MedicineRestExceptionHandler {
	
	//Add an Exception handler 
		
		@ExceptionHandler 
		public ResponseEntity<MedicineErrorResponse> handleException(Exception exc){
			
			//create a MedicineErrorResponse
			
			MedicineErrorResponse error = new MedicineErrorResponse();
			error.setStatus(HttpStatus.BAD_REQUEST.value());
			error.setMessage(exc.getMessage());
			error.setTimeStamp(System.currentTimeMillis());
			return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
			
			
		}
}
