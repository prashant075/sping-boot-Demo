package com.saveo.medicines.utility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import com.saveo.medicines.entity.Medicine;


public class MedicineCsvParse {
	public static List parser(InputStream instr) {
		BufferedReader fileReader = null;
		CSVParser csvParser = null;

		List<Medicine> medicines = new ArrayList<Medicine>();
		try {
			fileReader = new BufferedReader(new InputStreamReader(instr, "UTF-8"));
			csvParser = new CSVParser(fileReader,
					CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
 
			Iterable<CSVRecord> csvRecords = csvParser.getRecords();
			for (CSVRecord csvRecord :  csvRecords) {
				Medicine medicine = new Medicine(
				csvRecord.get("c_name"),
				csvRecord.get("c_batch_no"),
				csvRecord.get("d_expiry_date"),
				Integer.parseInt(csvRecord.get("n_balance_qty")),
				csvRecord.get("c_packaging"),
				csvRecord.get("c_unique_code"),	
				csvRecord.get("c_schemes"),
				Double.parseDouble(csvRecord.get("n_mrp")),
				csvRecord.get("c_manufacturer"),
				csvRecord.get("hsn_code"));
				
				medicines.add(medicine);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fileReader.close();
				csvParser.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return medicines;
	}
}
