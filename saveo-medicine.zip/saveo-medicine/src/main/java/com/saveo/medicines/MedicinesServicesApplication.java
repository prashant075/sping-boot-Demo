package com.saveo.medicines;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicinesServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicinesServicesApplication.class, args);
	}

}
