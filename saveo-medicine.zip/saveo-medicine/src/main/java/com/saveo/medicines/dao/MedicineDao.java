package com.saveo.medicines.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.saveo.medicines.entity.Medicine;

@Repository
public class MedicineDao {

	private EntityManager entitymanager;

	@Autowired
	public MedicineDao(EntityManager theEntitymanager) {
		entitymanager = theEntitymanager;
	}

	public List<Medicine> findAll(String itemName) {
		Session currentSession = entitymanager.unwrap(Session.class);

		
		Query<Medicine> theQuery = currentSession.createQuery("from Medicine as m where m.c_name like :c_name");
		
		theQuery.setParameter("c_name", itemName + "%");
		
		List<Medicine> theemp = theQuery.getResultList();
		
		
		return theemp;
	}

	public Medicine findById(String theId) {

		Session currentSession = entitymanager.unwrap(Session.class);

		
		Query<Medicine> theQuery = currentSession.createQuery("from Medicine where c_unique_code=:c_unique_code")
				.setMaxResults(1);

		theQuery.setParameter("c_unique_code", theId);
		
		
		Medicine theemp = theQuery.uniqueResult();
		
		return theemp;

	}

	public void saveAll(List<Medicine> lstMedicines) {
		
		Session currentSession = entitymanager.unwrap(Session.class);
		for (Medicine medicine : lstMedicines) {
			currentSession.save(medicine);
		}

	}

}
